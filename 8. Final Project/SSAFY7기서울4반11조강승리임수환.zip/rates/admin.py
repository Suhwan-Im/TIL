from django.contrib import admin
from .models import Movierate, Rate

# Register your models here.
admin.site.register(Movierate)
admin.site.register(Rate)